from bs4 import BeautifulSoup
import json
import re
html="""
<section id="experience-section" class="pv-profile-section experience-section ember-view"><header class="pv-profile-section__card-header">
  <h2 class="pv-profile-section__card-heading">
    Experience
  </h2>

<!----></header>

  <ul class="pv-profile-section__section-info section-info pv-profile-section__section-info--has-no-more">
<li id="ember2122" class="pv-entity__position-group-pager pv-profile-section__list-item ember-view">        <section id="1341754092" class="pv-profile-section__card-item-v2 pv-profile-section pv-position-entity ember-view">  <div class="display-flex justify-space-between full-width">
    <div class="display-flex flex-column full-width">
<a data-control-name="background_details_company" href="/company/infosys/" id="ember2124" class="full-width ember-view">          <div class="pv-entity__logo company-logo">
  <img src="https://media-exp1.licdn.com/dms/image/C560BAQEARy_xdMxOLg/company-logo_100_100/0?e=1600905600&amp;v=beta&amp;t=-kHztSjSD5oo0-vqnwtFYwZyy5c8IxMmUZhHs7CW878" loading="lazy" alt="Infosys Limited" id="ember2126" class="pv-entity__logo-img EntityPhoto-square-5 lazy-image ember-view">
</div>
<div class="pv-entity__summary-info pv-entity__summary-info--background-section ">
  <h3 class="t-16 t-black t-bold">systems engineer</h3>
  <p class="visually-hidden">Company Name</p>
  <p class="pv-entity__secondary-title t-14 t-black t-normal">
      Infosys Limited
<!---->  </p>
    <div class="display-flex">
    <h4 class="pv-entity__date-range t-14 t-black--light t-normal">
      <span class="visually-hidden">Dates Employed</span>
      <span>Feb 2018 – Present</span>
    </h4>
      <h4 class="t-14 t-black--light t-normal">
        <span class="visually-hidden">Employment Duration</span>
        <span class="pv-entity__bullet-item-v2">2 yrs 5 mos</span>
      </h4>
  </div>

  <h4 class="pv-entity__location t-14 t-black--light t-normal block">
    <span class="visually-hidden">Location</span>
    <span>Bhubaneshwar Area, India</span>
  </h4>

<!---->
</div>

</a>
<!---->    </div>

<!---->  </div>
</section>
</li>  </ul>

<!----></section>
"""
#  t=BeautifulSoup(html,'html.parser').find("p",{"class":"pv-entity__secondary-title pv-entity__degree-name t-14 t-black t-normal"}).find("span",{"class":"pv-entity__comma-item"})
def clean_string(var):
    var=str(var)
    var=var.strip()
    var=var.replace('\n','')
    return var
html_soup = BeautifulSoup(html,'html.parser')
IDs = []
Defaults= []
Defaults = {'designation':'', 'company':'','dates_employed':'','employ_duration':''}
expdict = dict.fromkeys(IDs, Defaults)
name='aaa'
if name is not None :
	# print(expsect)
	i=0
	xx=html_soup.find("section", {"id":"experience-section"})
	print('@@@2'+xx.text)
	if(html_soup.find("section", {"class":"pv-profile-section experience-section ember-view"})):
	 expsect=html_soup.find("section", {"id":"experience-section"})
	 for k in expsect.find_all("section",{"pv-profile-section__card-item-v2 pv-profile-section pv-position-entity ember-view"}) :
            expdict[i]={'designation': clean_string(k.find("h3",{"class":"t-16 t-black t-bold"}).text) if k.find("h3",{"class":"t-16 t-black t-bold"}) else '',
                        'company': clean_string(k.find("p",{"class":"pv-entity__secondary-title t-14 t-black t-normal"}).text) if k.find("p",{"class":"pv-entity__secondary-title t-14 t-black t-normal"}) else '',
                        'employ_duration':clean_string(k.find("span",{"class":"pv-entity__bullet-item-v2"}).text) if k.find("span",{"class":"pv-entity__bullet-item-v2"}) else '',
                        'dates_employed': clean_string(k.find("h4",{"class":"pv-entity__date-range t-14 t-black--light t-normal"}).find("span",{"class":""}).text) if k.find("h4",{"class":"pv-entity__date-range t-14 t-black--light t-normal"}) else ''
                        }
            i=i+1 
for x, y in expdict.items():
    print(x, y)  
 
	